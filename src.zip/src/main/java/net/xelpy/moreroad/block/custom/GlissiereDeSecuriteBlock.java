package net.xelpy.moreroad.block.custom;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class GlissiereDeSecuriteBlock extends HorizontalDirectionalBlock {
    /* V101 : hitbox ajustée aux dimensions exactes du modèle. */
    public static final MapCodec<GlissiereDeSecuriteBlock> CODEC = simpleCodec(GlissiereDeSecuriteBlock::new);
    private static final VoxelShape SHAPE_NORTH = Block.box(0, 0, 6.275, 16, 13.10636, 9);
    private static final VoxelShape SHAPE_SOUTH = Block.box(0, 0, 7, 16, 13.10636, 9.725);
    private static final VoxelShape SHAPE_EAST = Block.box(7, 0, 0, 9.725, 13.10636, 16);
    private static final VoxelShape SHAPE_WEST = Block.box(6.275, 0, 0, 9, 13.10636, 16);

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    public GlissiereDeSecuriteBlock(Properties pProperties) {
        super(pProperties.noOcclusion());
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected VoxelShape getShape(BlockState pState, BlockGetter pLevel, BlockPos pPos, CollisionContext pContext) {
        return switch (pState.getValue(FACING)) {
            case SOUTH -> SHAPE_SOUTH;
            case EAST -> SHAPE_EAST;
            case WEST -> SHAPE_WEST;
            default -> SHAPE_NORTH;
        };
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext pContext) {
        return this.defaultBlockState().setValue(FACING, pContext.getHorizontalDirection().getOpposite());
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> pBuilder) {
        pBuilder.add(FACING);
    }
}